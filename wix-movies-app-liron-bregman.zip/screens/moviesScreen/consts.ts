export const IMAGE_BASE_URL = 'https://image.tmdb.org/t/p/w92';
export const API_ERROR = 'Failed to fetch movies';
export const FETCH_ERROR = 'Failed to fetch movies';
