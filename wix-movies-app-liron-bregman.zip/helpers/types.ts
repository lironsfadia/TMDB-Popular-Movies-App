export interface FontModificatorType {
  fontWeight: string | number;
  fontSize: number;
  lineHeight: number;
  color: string;
}
